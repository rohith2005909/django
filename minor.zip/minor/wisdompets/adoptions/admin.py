from django.contrib import admin
from .models import Pet

@admin.register(Pet)
class PetAdmin(admin.ModelAdmin):
    # Columns shown in the pet list view
    list_display = ['name', 'breed', 'age', 'species', 'sex', 'is_adopted']

    # Filters in the sidebar
    list_filter = ['species', 'sex', 'is_adopted']

    # Search bar for specific fields
    search_fields = ['name', 'breed']
