from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .models import Pet, Adoption
from .forms import AdoptionForm  

# <-- Make sure to import AdoptionForm!

# Home page view
def home(request):
    pets = Pet.objects.all()
    return render(request, 'home.html', {'pets': pets})

# Pet details view
def pet_details(request, pet_id):
    try:
        pet = Pet.objects.get(id=pet_id)
    except Pet.DoesNotExist:
        raise Http404('Pet not found')
    return render(request, 'pet_details.html', {'pet': pet})

# Signup view
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully! You can now log in.')
            return redirect('login')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

# Pet adoption view
def adopt_pet(request, pet_id):
    pet = get_object_or_404(Pet, id=pet_id)
    if request.method == 'POST':
        form = AdoptionForm(request.POST)
        if form.is_valid():
            adoption = form.save(commit=False)
            adoption.pet = pet
            adoption.save()
            pet.is_adopted = True
            pet.save()
            return redirect('home')
    else:
        form = AdoptionForm()
    return render(request, 'adopt_pet.html', {'form': form, 'pet': pet})



def adopted_pets(request):
    adoptions = Adoption.objects.select_related('pet').all()  # Get all adoptions with pet details
    return render(request, 'adopted_pets.html', {'adoptions': adoptions})
