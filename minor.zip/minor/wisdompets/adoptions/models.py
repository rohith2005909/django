from django.db import models

class Vaccine(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Pet(models.Model):
    SEX_CHOICES = [('M', 'Male'), ('F', 'Female')]

    name = models.CharField(max_length=200)
    breed = models.CharField(max_length=30, blank=True)
    submitter = models.CharField(max_length=30)
    species = models.CharField(max_length=30)
    description = models.TextField()
    sex = models.CharField(max_length=1, choices=SEX_CHOICES, blank=True)
    age = models.IntegerField(null=True)
    submission_date = models.DateTimeField()
    vaccinations = models.ManyToManyField(Vaccine, blank=True)
    is_adopted = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class Adoption(models.Model):
    pet = models.ForeignKey(Pet, on_delete=models.CASCADE)
    adopter_name = models.CharField(max_length=100)
    adopter_email = models.EmailField()
    adopter_phone = models.CharField(max_length=15)
    adoption_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.adopter_name} adopted {self.pet.name}"
